phpBB style name: afterburner2
Designed by: RocketTheme, LLC
http://www.rockettheme.com/phpbb3
     
     This is the readme.txt file with short description of the phpBB3 style funcionality and configuration.This is the full Afterburner2 style with RokBB3 support enabled. Also, RokBox,RokTabs and few other RocketTheme scripts are included.
     
     1. Installation
     
     Style is installed as the usual phpBB3 style. You MUST activate php support in templates first in the phpBB3 Administration Control Panel. If you don't do that style may not work properly and some features will be unavailable. Remember to purge the cache in phpBB3 ACP after enabling PHP support in templates.
     
     For basic style installation instructions please refer to: https://www.phpbb.com/kb/article/how-to-install-styles-on-phpbb3/.
     
     For extended installation manual, documentation, and support please visit: http://www.rockettheme.com/forum/index.php?f=137&rb_v=viewforum
     Also, for full reference about RokBB3 and RokBox, please go to: http://www.rockettheme.com/phpbb3-styles/afterburner2
     
     1.1 Enabling PHP support in templates.
     
     Please log in into your phpBB3 Administration Control Panel. Go to "General"  tab. Next, choose "Security settings" and set "Allow php in templates" to Yes.
     
     2. Style configuration
     
     phpBB3 style is configured as any other phpBB3 style, however we have made few little additions to the basic prosilver style. You can completly configure forum layout by changing options using RokBB3. Near the every option there is description explaining how current setting works.
     
     For extended RokBB installation manual, documentation, and support please visit: http://www.rockettheme.com/phpbb3-styles/afterburner2
     
     If you decide NOT to use RokBB3, you can configure your forum layout in following files:
     
     template/afterburner2.php - layout settings
          
     3. Sources
     
     Sources are Adobe Fireworks slices, which you can easily modify and adjust it to fit your needs.
     
     4. More Information
     
     For more informations about RocketTheme phpBB3 styles please visit http://www.rockettheme.com/phpbb3
    